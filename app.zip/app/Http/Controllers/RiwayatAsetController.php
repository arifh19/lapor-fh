<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\RiwayatAset;
use App\Transformers\RiwayatAsetTransformer;
use Laratrust\LaratrustFacade as Laratrust;

class RiwayatAsetController extends Controller
{
    /**
     * Contructor
     */
    public function __construct(RiwayatAset $riwayat,RiwayatAsetTransformer $riwayatTransformer){
        $this->riwayat = $riwayat;
        $this->riwayatTransformer = $riwayatTransformer;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ((Laratrust::hasRole('admin'))||(Laratrust::hasRole('teknis'))) {
            $riwayats = $this->riwayatTransformer->transformCollection($this->riwayat->all());
            return response()->json($riwayats);
        }
        else{
            return response()->json(['error' => true, 'message' => 'Anda tidak memiliki izin']);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
